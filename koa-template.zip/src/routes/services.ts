import Router from '@koa/router';

const router = new Router({
  prefix: '/services',
});

export default router;
