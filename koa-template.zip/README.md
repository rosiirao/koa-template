# koa-template
A template for koa project

## configuration

copy _config.json.template_ to _config_ directory. see [config](https://github.com/lorenwest/node-config).

## development and test

use _.env_ to set environment variable.
